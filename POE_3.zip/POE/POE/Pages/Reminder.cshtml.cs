using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using POE.Student;

namespace POE.Pages
{
    public class ReminderModel : PageModel
    {
        private readonly Library _library;
        public Library LO = new Library();
        public Library Getuser = new Library();

        public ReminderModel()
        {
            _library = new Library();
        }
        public void OnGet()
        {
            var user = HttpContext.Session.GetString("Username");
            //string user = Request.Query["User"];
            Getuser = Getuser.GetUser(user);
            string ModuleCode = Request.Query["ModuleCode"];
            LO = LO.GetModule(ModuleCode, user);
        }
        public void OnPost()
        {
            string ModuleCode = Request.Form["txtModuleCode"];
            string User = Request.Form["txtuser"];
            double ReminderDate = Convert.ToInt32(Request.Form["txtNumberOfWeeks"]);
            DateTime Stardate = Convert.ToDateTime(Request.Form["txtStartDate"]);
            //TimeOnly time = Convert.ToDateTime(Request.Form[""]);
          

            //Library KO = new Library(ModuleCode, NumOfWeeks, Stardate, User);
            //KO.Update(ModuleCode, User);
            //HttpContext.Session.SetString("Username", User);
            //Response.Redirect($"/AllModules");


        }
    }
}
