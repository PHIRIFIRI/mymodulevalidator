using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using POE.Student;

namespace POE.Pages
{
    public class UpdateModel : PageModel
    {
        public Library Edit = new Library();
        public void OnGet()
        {
            string ModuleCode = Request.Query["ModuleCode"];
            var Username = HttpContext.Session.GetString("Username");
            Edit = Edit.GetModule(ModuleCode,Username);
        }

        public void OnPost()
        {
            string ModuleCode = Request.Form["txtModuleCode"];
            string ModuleName = Request.Form["txtModuleName"];
            double NumOfCredits = Convert.ToInt32(Request.Form["txtNumberOfCredits"]);
            double ClassPerHour = Convert.ToInt32(Request.Form["txtClassperWeek"]);
            double NumOfWeeks = Convert.ToInt32(Request.Form["txtNumberOfWeeks"]);
            DateTime Stardate = Convert.ToDateTime(Request.Form["txtStartDate"]);
            string User = Request.Form["txtuser"];

            Library KO = new Library(ModuleCode, ModuleName, NumOfCredits, ClassPerHour, NumOfWeeks, Stardate, User);
            KO.Update(ModuleCode,User);
            HttpContext.Session.SetString("Username", User);
            Response.Redirect($"/AllModules");

        }

    }
}
