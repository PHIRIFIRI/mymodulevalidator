using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using POE.Student;

namespace POE.Pages
{
    public class NewModuleModel : PageModel
    {

        public Library LO = new Library();
        public Library Getuser = new Library();
        public void OnGet()
        {
            var user = HttpContext.Session.GetString("Username");
            //string user = Request.Query["User"];
            Getuser = Getuser.GetUser(user);


        }
        public void OnPost()
        {
            string ModuleCode = Request.Form["txtModuleCode"];
            string ModuleName = Request.Form["txtModuleName"];
            double NumOfCredits = Convert.ToInt32(Request.Form["txtNumberOfCredits"]);
            double ClassPerHour = Convert.ToInt32(Request.Form["txtClassperWeek"]);
            double NumOfWeeks = Convert.ToInt32(Request.Form["txtNumberOfWeeks"]);
            DateTime Stardate = Convert.ToDateTime(Request.Form["txtStartDate"]);
            string User = Request.Form["txtuser"];

            Library KO = new Library(ModuleCode, ModuleName, NumOfCredits, ClassPerHour, NumOfWeeks, Stardate, User);
            KO.addNew();
            HttpContext.Session.SetString("Username", User);
            Response.Redirect($"/AllModules");
            
        }

    }
}
