using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using POE.Student;

namespace POE.Pages
{
    public class RegisterModel : PageModel
    {
        public void OnGet()
        {
        }
        public void OnPost()
        {
            
            string Username = Request.Form["txtUsername"];
            string Name = Request.Form["txtName"];
            string Surname = Request.Form["txtSurname"];
            string Password = Request.Form["txtPass"];
            string Conpassword = Request.Form["txtConPass"];
            try
            {
                if (Password != Conpassword)
                {
                    Response.Redirect("/Register");
                }
                else
                {
                    Library em = new Library(Username, Name, Surname, Password);
                    em.Register();

                    Response.Redirect("/Index");

                }

            }
            catch(Exception ex)
            {
                Response.Redirect("/Register");

            }
            finally
            {

            }
          
           

        }

    }
}
