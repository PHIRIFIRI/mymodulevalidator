﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using POE.Student;

namespace POE.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {

        }
        public void OnPost()
        {
            string Username = Request.Form["txtUsername"];
            string Password = Request.Form["txtPass"];
            try
            {
                Library em = new Library(Username, Password);
                em.Login(Username, Password);

                if (em.Username.Equals(Username) && em.Password.Equals(Password))
                {
                    HttpContext.Session.SetString("Username", Username);
                    
                     Response.Redirect($"/AllModules?Username={Username}");
                }
                else
                {
                    Response.Redirect("/Index");
                }

            }
            catch(Exception e)
            {
                Response.Redirect("/Index");

            }
           
        }
    }
}