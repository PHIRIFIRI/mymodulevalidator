using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using POE.Student;

namespace POE.Pages
{
    public class AllModulesModel : PageModel
    {
        public Library call = new Library();
        public List<Library> Modules =
           new List<Library>();
        public List<Library> Alert =
           new List<Library>();
        public void OnGet()
        {

           // string Username = Request.Query[""];
            string pass = "";
            var Username = HttpContext.Session.GetString("Username");
            if (Username == null)
            {
                Response.Redirect("/Index");
            }
            else {

                Library StudentModules = new Library(Username, pass);
                Modules = StudentModules.AllModules(Username);
                call = call.GetUser(Username);
                Alert = StudentModules.GetAlert(Username);

            }
        }
        public void OnPost()
        {
            //HttpContext.Session.SetString("Username", Username);
        }
       
    }
}
