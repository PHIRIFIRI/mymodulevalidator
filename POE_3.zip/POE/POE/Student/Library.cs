﻿using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace POE.Student
{
    public class Library
    {
        //SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\mondlimongezi\Downloads\POE1\POE\POE\Data\SchoolDetails.mdf;Integrated Security=True");//Paste a connection string here
	SqlConnection con = Connections.GetConnection();//Paste a connection string here
                                                    //Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\lab_services_student\Downloads\ST10103128_Thukwana_Mondli_Mongezi_POE\ST10103128_Thukwana_Mondli_Mongezi_POE\POE Part 3\POE\POE\SchoolDetails.mdf;Integrated Security=True

        public string Module_Code { get; set; }
        public string Module_Name { get; set; }
        public double Number_Of_Credits { get; set; }
        public double Class_Hour_Per_Week { get; set; }
        public double Number_Of_Weeks { get; set; }
        public double self_Study { get; set; }
        public DateTime Starting_Date { get; set; }

        //public double Hours_Spent { get; set; }

        //Login or Register
        public string Username { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Password { get; set; }
        public string ModuleCode { get; }

        // double self_Study;

        //Constractor SelfStudy
        public Library()
        {

        }


        public Library(string module_Code, string module_Name, double number_Of_Credits, double class_Hour_Per_Week,
                        double number_Of_Weeks, DateTime starting_Date, string user)
        {
            Module_Code = module_Code;
            Module_Name = module_Name;
            Number_Of_Credits = number_Of_Credits;
            Class_Hour_Per_Week = class_Hour_Per_Week;
            Number_Of_Weeks = number_Of_Weeks;
            self_Study = SelfStudy();
            Starting_Date = starting_Date;
            Username = user;
            
        }
        //For Register
        public Library(string username, string name, string surname, string password)
        {
            Username = username;
            Name = name;
            Surname = surname;
            Password = password;
        }

        public Library(string username, string password)
        {
            Username = username;
            Password = password;
        }

        public Library(string moduleCode, DateTime stardate, string user)
        {
            Module_Code = moduleCode;
            Starting_Date = stardate;
            Username = user;
        }

        //inserting values into the Database
        public void addNew()
        {
            SqlCommand cmd = new SqlCommand($"INSERT INTO tblModules(ModuleCode,ModuleName, NumberOfCredits, ClassHoursPerWeek, NumberOfWeeks,SelfStudy,StartDate, Username) " +
                $"VALUES('{Module_Code}','{Module_Name}','{Number_Of_Credits}','{Class_Hour_Per_Week}','{Number_Of_Weeks}','{self_Study}','{Starting_Date}','{Username}')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();


        }

        public void Reminder()
        {
            try
            {
                if (string.IsNullOrEmpty(Module_Code))
                {
                    Console.WriteLine("Module_Code cannot be null or empty.");
                    return;
                }

                using (SqlCommand cmd = new SqlCommand("INSERT INTO tblReminder(ModuleCode, Reminder, Username) " +
                    "VALUES(@ModuleCode, @Reminder, @Username)", con))
                {
                    cmd.Parameters.Add("@ModuleCode", SqlDbType.NVarChar, 50).Value = Module_Code; // Adjust the size accordingly
                    cmd.Parameters.Add("@Reminder", SqlDbType.DateTime).Value = Starting_Date;
                    cmd.Parameters.Add("@Username", SqlDbType.NVarChar, 50).Value = Username; // Adjust the size accordingly

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                // Log the exception or handle it appropriately
                Console.WriteLine($"Error in Reminder method: {ex.Message}");
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }


        //Register
        public void Register()
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand($"INSERT INTO tblStudent(Username,Name, Surname, Password) " +
                    $"VALUES('{Username}','{Name}','{Surname}','{Password}')", con))
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                // Log the exception or handle it appropriately
                Console.WriteLine($"Error in Register method: {ex.Message}");
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        //Login
        public Library Login(string User, string pass)
        {
            string strSelect = $"SELECT * FROM tblStudent WHERE Username = '{User}'  AND Password = '{pass}'";
            SqlCommand cmdSelect = new SqlCommand(strSelect, con);
            con.Open();
            using (SqlDataReader reader = cmdSelect.ExecuteReader())
            {
                while (reader.Read())
                {
                    Username = (string)reader[0]; ////you can specify what column you want
                    Name = (string)reader[1];
                    Surname = (string)reader[2];
                    Password = (string)reader[3];
                }
            }
            con.Close();
            return new Library(Username, Name, Surname, Password);
        }

        //[Route("Logout")]
        //public IActionResult Logout()
        //{
        //    HttpContext.Session.Remove("Username");
        //    return Response.Redirect("/Index");
        //}
        //Get username 
        public Library GetUser(string user)
        {
            string strSelect = $"SELECT * FROM tblStudent WHERE  Username =  '{user}'";
            SqlCommand cmdSelect = new SqlCommand(strSelect, con);
            con.Open();
            using (SqlDataReader reader = cmdSelect.ExecuteReader())
            {
                while (reader.Read())
                {
                    Username = (string)reader[0]; ////you can specify what column you want
                    Name = (string)reader[1];
                    Surname = (string)reader[2];
                    Password = (string)reader[3];
                }
            }
            con.Close();
            return new Library(Username, Name, Surname, Password);
        }
        //Delete fuction
        public void delete(string Modcode, string User)
        {
            string strDelete = $"DELETE FROM tblModules WHERE ModuleCode = '{Modcode}' AND '{User}' = tblModules.Username";
            SqlCommand cmdDelete = new SqlCommand(strDelete, con);
            
            con.Open();
            cmdDelete.ExecuteNonQuery();
            con.Close();
        }
        //Update fuction
        public void Update(string Code,string User)
        {
            SqlCommand cmdUpdate = 
                new SqlCommand($"UPDATE tblModules SET ModuleName = '{Module_Name}', NumberOfCredits = '{Number_Of_Credits}', " +
                $"ClassHoursPerWeek = '{Class_Hour_Per_Week}', NumberOfWeeks = '{Number_Of_Weeks}', " +
                $"SelfStudy = '{self_Study}', StartDate = '{Starting_Date}' WHERE ModuleCode = '{Code}' AND Username = '{User}' ", con);

            con.Open();
            cmdUpdate.ExecuteNonQuery();
            con.Close();

        }
        //Displaying User Hours spent on a module
        public List<Library> OneModule(string users, string ModuleCode)
        {
            SqlCommand cmdSelect =
                new SqlCommand($"SELECT * FROM tblModules WHERE '{users}' = tblModules.Username AND '{ModuleCode}' = tblModules.ModuleCode", con);

            DataTable myTable = new DataTable();
            DataRow myRow;
            SqlDataAdapter myAdapter = new SqlDataAdapter(cmdSelect);
            List<Library> eList = new List<Library>();

            con.Open();
            myAdapter.Fill(myTable);

            if (myTable.Rows.Count > 0)
            {
                for (int i = 0; i < myTable.Rows.Count; i++)
                {
                    myRow = myTable.Rows[i];
                    Module_Code = (string)myRow["ModuleCode"]; //using a column name
                    Module_Name = (string)myRow[1]; //using a column index
                    Number_Of_Credits = Convert.ToDouble(myRow[2]);
                    Class_Hour_Per_Week = Convert.ToDouble(myRow[3]);
                    Number_Of_Weeks = Convert.ToDouble(myRow[4]);
                    self_Study = Convert.ToDouble(myRow[5]);
                    Starting_Date = (DateTime)myRow[6];
                    Username = (string)myRow[7];

                    eList.Add(new Library(Module_Code, Module_Name, Number_Of_Credits, Class_Hour_Per_Week, Number_Of_Weeks, Starting_Date, Username/*,Hours_Spent*/));
                }

            }
            else
            {

            }

            return eList;

        }
        //Dislpaying all users Modules For the user
        public List<Library> AllModules(string users)
        {
            // string strSelect = $"SELECT * FROM tblModules  WHERE Username = '{Username}'"; WHERE tblModules.Username = '{Username}'
            SqlCommand cmdSelect = new SqlCommand($"SELECT * FROM tblModules WHERE Username = '{users}'", con);

            DataTable myTable = new DataTable();
            DataRow myRow;
            SqlDataAdapter myAdapter = new SqlDataAdapter(cmdSelect);
            List<Library> eList = new List<Library>();

            con.Open();
            myAdapter.Fill(myTable);

            if (myTable.Rows.Count > 0)
            {
                for (int i = 0; i < myTable.Rows.Count; i++)
                {
                    myRow = myTable.Rows[i];
                    Module_Code = (string)myRow["ModuleCode"]; //using a column name
                    Module_Name = (string)myRow[1]; //using a column index
                    Number_Of_Credits = Convert.ToDouble(myRow[2]);
                    Class_Hour_Per_Week = Convert.ToDouble(myRow[3]);
                    Number_Of_Weeks = Convert.ToDouble(myRow[4]);
                    self_Study = Convert.ToDouble(myRow[5]);
                    Starting_Date = (DateTime)myRow[6];
                    Username = (string)myRow[7];

                    eList.Add(new Library(Module_Code, Module_Name, Number_Of_Credits, Class_Hour_Per_Week, Number_Of_Weeks, Starting_Date, Username/*,Hours_Spent*/));
                }
            }

            return eList;
        }

        public Library GetModule(string code, string user)
        {
           // string strSelect = $"SELECT * FROM tblModules WHERE ModuleCode = '{code}', Username =  '{user}'";
            string strSelect = $"SELECT * FROM tblModules WHERE ModuleCode = '{code}' AND Username =  '{user}'";
            SqlCommand cmdSelect = new SqlCommand(strSelect, con);
            con.Open();
            using (SqlDataReader reader = cmdSelect.ExecuteReader())
            {
                while (reader.Read())
                {
                    Module_Code = (string)reader[0]; ////you can specify what column you want
                    Module_Name = (string)reader[1];
                    Number_Of_Credits = Convert.ToDouble(reader[2]);
                    Class_Hour_Per_Week = Convert.ToDouble(reader[3]);
                    Number_Of_Weeks = Convert.ToDouble(reader[4]);
                    self_Study = Convert.ToDouble(reader[5]);
                    Starting_Date = (DateTime)reader[6];
                    Username = (string)reader[7];
                }
            }
            con.Close();
            return new Library(Module_Code, Module_Name, Number_Of_Credits, Class_Hour_Per_Week, Number_Of_Weeks, Starting_Date, Username/*,Hours_Spent*/);
        }
        public List<Library> GetAlert(string user)
        {
            // string strSelect = $"SELECT * FROM tblModules  WHERE Username = '{Username}'"; WHERE tblModules.Username = '{Username}'
            SqlCommand cmdSelect = new SqlCommand($"SELECT * FROM tblReminder WHERE Username = '{user}'", con);

            DataTable myTable = new DataTable();
            DataRow myRow;
            SqlDataAdapter myAdapter = new SqlDataAdapter(cmdSelect);
            List<Library> eList = new List<Library>();

            //con.Open();
            myAdapter.Fill(myTable);

            if (myTable.Rows.Count > 0)
            {
                for (int i = 0; i < myTable.Rows.Count; i++)
                {
                    myRow = myTable.Rows[i];
                    Module_Code = (string)myRow["ModuleCode"]; //using a column name
                    Starting_Date = (DateTime)myRow[2];
                    Username = (string)myRow[3];

                    eList.Add(new Library(Module_Code,Starting_Date, Username));
                }
            }

            return eList;
        }
        //Calculating self Study
        public int SelfStudy()
        {

            self_Study = ((Number_Of_Credits * 10) / Number_Of_Weeks) - Class_Hour_Per_Week;

            return (int)self_Study;
        }
        //Calcilating Remaining Weeks
        public double Weeks()
        {
            var Duration = ((12 * 4) - ((DateTime.Now.Month) * 4));


            if (DateTime.Now.Day < 6)
            {
                return Duration;
            }
            else if (DateTime.Now.Day < 12)
            {
                return Duration - 1;
            }
            else if (DateTime.Now.Day < 18)
            {
                return Duration - 2;
            }
            else if (DateTime.Now.Day < 22)
            {
                return Duration - 3;
            }

            return Duration - 4;

        }
        //Calculating Remaing Day
        public double RemainingDays()
        {
            var Days = Weeks() * 7;
            return Days - DateTime.Now.Day;
        }
        //Calculating Remaining Hours
        public double RemainingHours()
        {
            double Remaining_hours = SelfStudy() /*- Hours_Spent*/;
            return Remaining_hours;
        }
        //Display method
        public string getDetails()
        {
            return "Code = " + Module_Code +
                "\nName = " + Module_Name +
                "\nNumber of Credits = " + Number_Of_Credits.ToString() +
                "\nClass Per Hour = " + Class_Hour_Per_Week.ToString() +
                "\nNumber Of Weeks = " + Number_Of_Weeks.ToString() +
                "\nSelf study per Hour = " + SelfStudy() +
                "\nStarting Date = " + Starting_Date.ToUniversalTime() +
                "\nRemaining Day = " + RemainingDays() +
                "\nRemaining  Weeks " + Weeks() +
                "\nRemaining  Hours " + RemainingHours() +
                "\n=========================";
        }
    }
}
