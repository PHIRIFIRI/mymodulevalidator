﻿using System.Data.SqlClient;

namespace POE.Student
{
    public class Connections
    {
        public static SqlConnection GetConnection()
        {
            string fileName = "Data\\SchoolDetails.mdf";
            string filePath = Path.GetFullPath(fileName).Replace(@"\bin\Debug", @"\Data");
            string strCon = $@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename={filePath};Integrated Security=True";
            return new SqlConnection(strCon);
        }
    }
}
